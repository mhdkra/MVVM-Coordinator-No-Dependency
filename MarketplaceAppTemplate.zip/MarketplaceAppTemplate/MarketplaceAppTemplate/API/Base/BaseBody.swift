//
//  BaseBody.swift
//  MarketplaceAppTemplate
//
//  Created by Tiara Mahardika on 13/07/22.
//

import Foundation
struct BaseBody: Codable {
}
